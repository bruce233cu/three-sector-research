"use client";
import { useEffect, useState } from "react";

export function useResearchData(initialFirms: any[], initialSigs: any[]) {
  const [data, setData] = useState({ firms: initialFirms, sigs: initialSigs, reports: [] as any[], updatedAt: "" });
  const [live, setLive] = useState(false);
  useEffect(() => {
    let active = true;
    fetch("/api/research", { cache: "no-store" })
      .then((response) => {
        if (!response.ok) throw new Error("Database unavailable");
        return response.json();
      })
      .then((next) => {
        if (active && Array.isArray(next.firms) && Array.isArray(next.sigs)) {
          setData(next);
          setLive(true);
        }
      })
      .catch(() => setLive(false));
    return () => { active = false; };
  }, []);
  return { ...data, live };
}
