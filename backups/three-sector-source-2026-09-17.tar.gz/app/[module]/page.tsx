"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Filter,
  Plus,
  Search,
} from "lucide-react";
import { Shell, Badge, firms as fallbackFirms, sigs as fallbackSigs, tracks } from "../research-ui";
import { useResearchData } from "../../hooks/use-research-data";
const cfg: Record<string, [string, string, string, string[]]> = {
  signals: [
    "前置信号",
    "前置信号扫描台",
    "从需求、供给和公司端捕捉未形成共识的变化",
    ["来源/公司", "赛道", "分类", "核心内容", "评分/利润", "状态/赔率", "详情"],
  ],
  opportunities: [
    "机会池",
    "机会池",
    "通过硬门槛后才进入深度研究",
    ["公司", "赛道", "入池原因", "研究阶段", "目标利润", "赔率", "详情"],
  ],
  companies: [
    "公司研究",
    "公司研究档案",
    "以事实链验证公司逻辑",
    ["公司", "赛道", "产业链位置", "客户订单", "实控人", "竞争格局", "档案"],
  ],
  profit: [
    "净利润核算",
    "净利润核算",
    "销量 × 单价 × 净利率拆解利润",
    ["公司", "业务", "产能", "单价", "收入增量", "净利率", "利润"],
  ],
  odds: [
    "赔率池",
    "赔率池",
    "目标市值与当前市值动态比较",
    ["公司", "当前市值", "目标利润", "合理PE", "目标市值", "赔率", "等级"],
  ],
  industry: [
    "产业链地图",
    "产业链地图",
    "从需求变化追踪到真正受益公司",
    ["赛道", "环节", "关键产品", "市场空间", "渗透率", "核心公司", "指标"],
  ],
  daily: [
    "历史日报",
    "历史日报与复盘",
    "用后续结果检验当时判断",
    ["日期", "信号", "入池", "判断", "验证", "结果", "命中率"],
  ],
};
export default function Page() {
  const { module } = useParams<{ module: string }>();
  const { firms, sigs, reports, live } = useResearchData(fallbackFirms, fallbackSigs);
  const c = cfg[module];
  if (!c) return null;
  const rows: any[] =
    module === "daily"
      ? (reports.length ? reports.map((r:any) => ({ id: r.id, date: r.report_date, track: r.strongest_sector || "三大赛道", type: "日报", title: r.summary || "当日研究日报", score: r.valid_signal_count, state: r.research_can_end ? "已结束" : "继续研究" })) : sigs)
      : module === "signals"
      ? sigs
      : module === "companies" || module === "profit" || module === "odds"
        ? firms.slice(0, 1)
        : firms;
  return (
    <Shell active={c[0]}>
      <div className="page-head">
        <div>
          <p className="eyebrow">WORKSPACE / {c[0]}</p>
          <h1>{c[1]}</h1>
          <p>{c[2]}</p>
        </div>
        <button className="primary">
          <Plus size={15} />
          新增记录
        </button>
      </div>
      <div className="list-card">
        <div className="toolbar">
          <label className="search">
            <Search size={15} />
            <input placeholder={`搜索${c[0]}`} />
          </label>
          <button>
            <Filter size={14} />
            全部赛道
          </button>
          <span>{live ? "实时数据库" : "本地回退"} · 共 {rows.length} 条记录</span>
        </div>
        <div className="data-table">
          <div className="data-head">
            {c[3].map((x) => (
              <span key={x}>{x}</span>
            ))}
          </div>
          {rows.map((r, i) => (
            <div className="data-row" key={r.code || r.id}>
              {c[3].map((x, j) => (
                <span key={x}>
                  {j === 0 ? (
                    r.code ? (
                      <>
                        <b className={`rank ${r.rank}`}>{r.rank}</b>
                        <i>
                          <strong>{r.name}</strong>
                            <small>{r.stockCode || r.code}</small>
                        </i>
                      </>
                    ) : (
                      <i>
                        <strong>今日 09:4{i}</strong>
                        <small>产业调研</small>
                      </i>
                    )
                  ) : j === 1 ? (
                    <Badge tone={tracks[r.track]}>{r.track}</Badge>
                  ) : j === 2 ? (
                    r.type || "核心零部件"
                  ) : j === 3 ? (
                    r.title || r.stage
                  ) : j === 4 ? (
                    r.score || r.profit
                  ) : j === 5 ? (
                    r.state || r.odds
                  ) : (
                    <Link
                      href={r.code ? `/company/${r.code}` : `/signals/${r.id}`}
                    >
                      查看 <ArrowRight size={14} />
                    </Link>
                  )}
                </span>
              ))}
            </div>
          ))}
        </div>
        <div className="pagination">
          <span>第 1–{rows.length} 条，共 {rows.length} 条</span>
          <button disabled>
            <ChevronLeft />
          </button>
          <b>1</b>
          <button>2</button>
          <button>3</button>
          <button>
            <ChevronRight />
          </button>
        </div>
      </div>
    </Shell>
  );
}
