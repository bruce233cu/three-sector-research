"use client";
import Link from "next/link";
import { ArrowRight, Bot, BrainCircuit, Orbit } from "lucide-react";
import { Shell, Badge, firms as fallbackFirms, sigs as fallbackSigs, tracks } from "./research-ui";
import { useResearchData } from "../hooks/use-research-data";
export default function Home() {
  const { firms, sigs, reports, live } = useResearchData(fallbackFirms, fallbackSigs);
  const latest = reports[0];
  return (
    <Shell active="总览">
      <div className="dashboard-head">
        <div>
          <p className="eyebrow">2026.09.08 · DAILY DECISION DESK</p>
          <h1>今天先做什么</h1>
          <p>首页只保留需要判断与推进的事项，完整数据进入二级页面。</p>
        </div>
        <div className="health">
          <i /> {live ? "数据库已连接" : "正在读取数据"}　<b>{sigs.length} 条</b>
        </div>
      </div>
      <div className="decision-grid">
        <section className="priority-board">
          <Title
            n="01"
            title="今日决策队列"
            note="按信息价值、时效性和赔率影响排序"
            link="/signals"
          />
          {sigs.slice(0, 6).map((s, i) => (
            <Link className="decision-row" href={`/signals/${s.id}`} key={s.id}>
              <em>0{i + 1}</em>
              <div>
                <Badge tone={tracks[s.track]}>{s.track}</Badge>
                <Badge>{s.type}</Badge>
                <strong>{s.title}</strong>
                <p>产业变化 · 等待下一层证据</p>
              </div>
              <div className="decision-action">
                <b>{s.score}</b>
                <span>{s.state}</span>
                <ArrowRight size={15} />
              </div>
            </Link>
          ))}
        </section>
        <aside className="today-summary">
          <Title n="02" title="今日结论" note="打开系统后先看这里" />
          <Summary l="信息记录" v={String(latest?.valid_signal_count ?? sigs.length)} n="数据库累计有效信号" />
          <Summary l="正式入池" v={String(latest?.new_pool_count ?? sigs.filter((x:any) => x.state === "入池").length)} n="最新日报新增" />
          <Summary l="公司研究" v={String(firms.length)} n="已建立研究档案" />
          <Summary l="待完成核算" v={String(firms.filter((x:any) => /待核算|未核算/.test(x.profit)).length)} n="优先补齐利润假设" />
          <Link className="next-action" href="/profit">
            继续处理待核算公司 <ArrowRight size={15} />
          </Link>
        </aside>
      </div>
      <div className="lane-grid">
        <Lane
          icon={<Bot />}
          name="机器人"
          score="82"
          state="信号增强"
          next="验证灵巧手供应商名单"
        />
        <Lane
          icon={<Orbit />}
          name="商业航天"
          score="76"
          state="扩散初期"
          next="核算卫星批产利润弹性"
        />
        <Lane
          icon={<BrainCircuit />}
          name="AI"
          score="68"
          state="高位分化"
          next="只保留业绩可验证公司"
        />
      </div>
      <section className="compact-panel">
        <Title
          n="03"
          title="高赔率公司优先级"
          note="首页只显示前5名"
          link="/opportunities"
        />
        <div className="mini-table">
          <div className="mini-head">
            <span>优先级 / 公司</span>
            <span>赛道</span>
            <span>研究阶段</span>
            <span>净利润</span>
            <span>赔率</span>
            <span>详情</span>
          </div>
          {firms.map((c) => (
            <Link href={`/company/${c.code}`} className="mini-row" key={c.code}>
              <span>
                <b className={`rank ${c.rank}`}>{c.rank}</b>
                <i>
                  <strong>{c.name}</strong>
                    <small>{c.stockCode || c.code}</small>
                </i>
              </span>
              <span>
                <Badge tone={tracks[c.track]}>{c.track}</Badge>
              </span>
              <span>{c.stage}</span>
              <span>{c.profit}</span>
              <span className="odds">{c.odds}</span>
              <span>
                查看档案 <ArrowRight size={14} />
              </span>
            </Link>
          ))}
        </div>
      </section>
    </Shell>
  );
}
function Title({
  n,
  title,
  note,
  link,
}: {
  n: string;
  title: string;
  note: string;
  link?: string;
}) {
  return (
    <div className="section-title">
      <div>
        <span>{n}</span>
        <div>
          <h2>{title}</h2>
          <p>{note}</p>
        </div>
      </div>
      {link && (
        <Link href={link}>
          查看全部 <ArrowRight size={14} />
        </Link>
      )}
    </div>
  );
}
function Summary({ l, v, n }: { l: string; v: string; n: string }) {
  return (
    <div className="summary-item">
      <div>
        <p>{l}</p>
        <span>{n}</span>
      </div>
      <strong>{v}</strong>
    </div>
  );
}
function Lane({
  icon,
  name,
  score,
  state,
  next,
}: {
  icon: React.ReactNode;
  name: string;
  score: string;
  state: string;
  next: string;
}) {
  return (
    <Link href="/industry" className={`lane ${tracks[name]}`}>
      <div className="lane-icon">{icon}</div>
      <div className="lane-body">
        <div>
          <strong>{name}</strong>
          <Badge tone={tracks[name]}>{state}</Badge>
        </div>
        <p>下一步：{next}</p>
        <div className="progress">
          <i style={{ width: score + "%" }} />
        </div>
      </div>
      <b>
        {score}
        <small>景气分</small>
      </b>
      <ArrowRight size={16} />
    </Link>
  );
}
