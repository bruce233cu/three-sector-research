"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { ArrowLeft, CheckCircle2, CircleDashed } from "lucide-react";
import { Shell, Badge, firms as fallbackFirms, sigs as fallbackSigs, tracks } from "../../research-ui";
import { useResearchData } from "../../../hooks/use-research-data";
export default function Page() {
  const { code } = useParams<{ code: string }>();
  const { firms } = useResearchData(fallbackFirms, fallbackSigs);
  const c = firms.find((x) => x.code === code);
  if (!c) return null;
  const isKeli = c.code === "ROB-KELI-001";
  const sections = isKeli
    ? [
        ["01", "公司业务", "六维力传感器、关节力矩传感器；传统称重传感器主业。2026H1营收8.38亿元，同比+22.27%；归母净利润1.31亿元。"],
        ["02", "入池原因", "机器人力学传感器从送样/小批量跨入批量供应，公司约141.1亿元且股价尚未明显交易这一变化。"],
        ["03", "产业链位置", "机器人核心零部件 / 力学传感器。"],
        ["04", "客户与订单", "90+机器人客户送样；2025全年销量超1500只，2026H1超2000只，4月后月订单超1000只，部分客户进入批量订单。"],
        ["05", "竞争优势", "传统传感器制造与客户基础，产品正从验证向批量过渡。"],
        ["06", "关键缺口", "机器人产品ASP、毛利率、费用率、2027/2028销量及归母净利贡献尚未核实。"],
      ]
    : [
        ["01", "机会名称", c.name],
        ["02", "入池依据", c.reason],
        ["03", "当前阶段", c.stage],
        ["04", "公司研究档案", "表格中尚未建立完整公司档案，需继续完成公司映射、订单穿透和利润核算。"],
      ];
  return (
    <Shell active="公司研究">
      <Link className="back" href="/companies">
        <ArrowLeft size={14} />
        返回公司列表
      </Link>
      <div className="record-head">
        <div>
          <Badge tone={tracks[c.track]}>{c.track}</Badge>
          <Badge>{c.stage}</Badge>
          <h1>
          {c.name} <small>{c.stockCode || c.code}</small>
          </h1>
          <p>最后更新：2026.09.08 09:42 · 核心假设验证中</p>
        </div>
        <div>
          <span>综合置信度</span>
          <strong>
            76<small>/100</small>
          </strong>
        </div>
        <div>
          <span>当前赔率</span>
          <strong>{c.odds}</strong>
        </div>
      </div>
      <div className="decision-strip">
        <div><span>当前判断</span><strong>{c.rank === "S" ? "优先核算" : "继续验证"}</strong></div>
        <div><span>变化强度</span><strong>{c.score.toFixed(1)} / 10</strong></div>
        <div><span>核心催化</span><strong>{isKeli ? "月订单跨过千只" : c.reason}</strong></div>
        <div><span>最大缺口</span><strong>{isKeli ? "ASP与毛利率" : "利润映射尚未完成"}</strong></div>
      </div>
      <div className="detail-layout">
        <div className="detail-main">
          {sections.map((x) => (
            <section className="detail-section" key={x[0]}>
              <div>
                <span>{x[0]}</span>
                <h2>{x[1]}</h2>
              </div>
              <p>{x[2]}</p>
            </section>
          ))}
        </div>
        <aside className="detail-side">
          <section>
            <h3>净利润与赔率</h3>
            <dl>
              <div>
                <dt>当前市值</dt>
                <dd>{c.marketCap}</dd>
              </div>
              <div>
                <dt>目标净利润</dt>
                <dd>{c.profit}</dd>
              </div>
              <div>
                <dt>核算状态</dt>
                <dd>待补关键参数</dd>
              </div>
              <div>
                <dt>目标赔率</dt>
                <dd>{c.odds}</dd>
              </div>
            </dl>
          </section>
          {isKeli && <section><h3>2028销量情景</h3><dl><div><dt>悲观</dt><dd>1万只</dd></div><div><dt>中性</dt><dd>3万只</dd></div><div><dt>乐观</dt><dd>10万只</dd></div></dl><p>ASP、毛利率、费用率、传统业务利润和估值倍数均待核实，不输出虚假利润。</p></section>}
          <section>
            <h3>核心假设验证</h3>
            {["订单规模增长", "毛利率提升", "客户完成导入", "费用率稳定"].map(
              (x, i) => (
                <div className="check" key={x}>
                  {i < 2 ? <CheckCircle2 /> : <CircleDashed />}
                  <span>
                    {x}
                    <small>{i < 2 ? "已有证据" : "待验证"}</small>
                  </span>
                </div>
              ),
            )}
          </section>
        </aside>
      </div>
    </Shell>
  );
}
