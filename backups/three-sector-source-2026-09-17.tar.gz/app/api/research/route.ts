import { NextResponse } from "next/server";

async function readTable(path: string) {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Supabase runtime configuration is missing");
  const response = await fetch(`${url}/rest/v1/${path}`, {
    headers: { apikey: key, Authorization: `Bearer ${key}` },
    cache: "no-store",
  });
  if (!response.ok) throw new Error(`Supabase request failed: ${response.status}`);
  return response.json();
}

export async function GET() {
  try {
    const [companyRows, signalRows, reportRows] = await Promise.all([
      readTable("companies?select=external_code,stock_code,name,status,odds_note,profit_note,rank,score,market_cap,pool_reason,sectors(name)&order=score.desc.nullslast"),
      readTable("signals?select=external_id,signal_date,title,change_description,signal_type,company_name,source_url,score,status,verification_needed,action,sectors(name)&order=signal_date.desc,score.desc&limit=200"),
      readTable("daily_reports?select=*&order=report_date.desc&limit=30"),
    ]);
    const firms = companyRows.map((row: any) => ({
      code: row.external_code,
      stockCode: row.stock_code,
      name: row.name,
      track: row.sectors?.name || "待分类",
      stage: row.status,
      odds: row.odds_note || "待核算",
      profit: row.profit_note || "待核算",
      rank: row.rank || "B",
      score: Number(row.score || 0),
      marketCap: row.market_cap == null ? "待核算" : `${Number(row.market_cap)}亿`,
      reason: row.pool_reason || "待补充入池依据",
    }));
    const sigs = signalRows.map((row: any) => ({
      id: row.external_id,
      date: row.signal_date,
      track: row.sectors?.name || "待分类",
      type: row.signal_type || "待分类",
      company: row.company_name || "待映射",
      title: row.title,
      score: (Number(row.score || 0) / 2).toFixed(1),
      state: row.action || row.status,
      source: row.source_url || "",
      change: row.change_description || "待补充变化说明",
      verify: row.verification_needed || "待补充验证节点",
    }));
    return NextResponse.json({ firms, sigs, reports: reportRows, updatedAt: new Date().toISOString() });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error" }, { status: 503 });
  }
}
