"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Shell, Badge, firms as fallbackFirms, sigs as fallbackSigs, tracks } from "../../research-ui";
import { useResearchData } from "../../../hooks/use-research-data";
export default function Page() {
  const { id } = useParams<{ id: string }>();
  const { sigs } = useResearchData(fallbackFirms, fallbackSigs);
  const s = sigs.find((x) => x.id === id);
  if (!s) return null;
  return (
    <Shell active="前置信号">
      <Link className="back" href="/signals">
        <ArrowLeft size={14} />
        返回信号列表
      </Link>
      <article className="signal-record">
        <p className="eyebrow">SIGNAL RECORD / {s.date}</p>
        <Badge tone={tracks[s.track]}>{s.track}</Badge>
        <Badge>{s.type}</Badge>
        <Badge>{s.state}</Badge>
        <h1>{s.title}</h1>
        <p className="lead">
          这条变化可能通过需求确认、供应链扩产、订单兑现和利润释放传导到上市公司。
        </p>
        <div className="signal-facts">
          {[
            ["相关公司", s.company],
            ["影响强度", s.score + " / 5"],
            ["影响周期", "3–12个月"],
            ["当前动作", s.state],
          ].map((x) => (
            <div key={x[0]}>
              <span>{x[0]}</span>
              <strong>{x[1]}</strong>
            </div>
          ))}
        </div>
        <section>
          <h2>产业链传导</h2>
          <div className="flow">
            <span>需求变化</span>
            <ArrowRight />
            <span>订单验证</span>
            <ArrowRight />
            <span>产能交付</span>
            <ArrowRight />
            <span>利润兑现</span>
          </div>
        </section>
        <section>
          <h2>下一步验证</h2>
          <p>{s.verify}</p>
          {s.source && (
            <a href={s.source} target="_blank" rel="noreferrer">
              查看原始来源
            </a>
          )}
        </section>
      </article>
    </Shell>
  );
}
